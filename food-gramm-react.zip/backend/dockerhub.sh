#!/bin/bash
echo 'docker build -t zhss1983/foodgram:latest ./'
`docker build -t zhss1983/foodgram:latest ./ `
echo 'docker push zhss1983/foodgram:latest'
`docker push zhss1983/foodgram:latest `
